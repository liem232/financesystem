const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const path = require('path');

const db = require('./models'); // index.js in models
const routes = require('./routes');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'layout');
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));


app.use('/', routes);


const PORT = process.env.PORT || 3000;

(async () => {
  try {
    await db.sequelize.sync({ force: false });
    const { User, Account } = db;
    const usersCount = await User.count();
    if (usersCount === 0) {
      const alice = await User.create({ name: 'Александр', email: 'ALEX@example.com' });
      const bob = await User.create({ name: 'САНЧОУС', email: 'SANCHOS@example.com' });
      await Account.create({ userId: alice.id, name: 'Основной', balance: 1000.00 });
      await Account.create({ userId: alice.id, name: 'Сбережения', balance: 2500.50 });
      await Account.create({ userId: bob.id, name: 'Кошелёк', balance: 300.00 });
      console.log('Добавлены аккаунты (Александр, САНЧОУС).');
    }
    app.listen(PORT, () => {
      console.log(`Сервер запущен на: http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Ошибка при запуске:', err);
  }
})();
