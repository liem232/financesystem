const db = require('../models');

module.exports = {
  dashboard: async (req, res) => {
    try {
      const users = await db.User.findAll({
        include: [{ model: db.Account }]
      });

      const transactions = await db.Transaction.findAll({
        order: [['createdAt', 'DESC']],
        limit: 50
      });

      const accounts = await db.Account.findAll({ include: [db.User] });
      const accMap = {};
      accounts.forEach(a => accMap[a.id] = a);

      const { error, success } = req.query || {};
      res.render('index', { users, transactions, accMap, error, success });
    } catch (err) {
      console.error(err);
      res.status(500).send('Ошибка сервера');
    }
  }
};
