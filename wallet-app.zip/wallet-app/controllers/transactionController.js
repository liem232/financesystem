const db = require('../models');
const { sequelize } = db;

module.exports = {
  createDeposit: async (req, res) => {
    const { accountId, amount, description } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) return res.redirect('/?error=invalid_amount');

    const t = await sequelize.transaction();
    try {
      const account = await db.Account.findByPk(accountId, { transaction: t, lock: t.LOCK.UPDATE });
      if (!account) throw new Error('Account not found');

      account.balance = parseFloat(account.balance) + amt;
      await account.save({ transaction: t });

      await db.Transaction.create({
        type: 'deposit',
        amount: amt,
        description,
        fromAccountId: null,
        toAccountId: account.id
      }, { transaction: t });

      await t.commit();
      res.redirect('/');
    } catch (err) {
      await t.rollback();
      console.error(err);
      res.redirect('/?error=deposit_failed');
    }
  },

  createPurchase: async (req, res) => {
    const { accountId, amount, description } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) return res.redirect('/?error=invalid_amount');

    const t = await sequelize.transaction();
    try {
      const account = await db.Account.findByPk(accountId, { transaction: t, lock: t.LOCK.UPDATE });
      if (!account) throw new Error('Account not found');

      if (parseFloat(account.balance) < amt) {
        await t.rollback();
        return res.redirect('/?error=' + encodeURIComponent('Недостаточно средств на счёте'));
      }

      account.balance = parseFloat(account.balance) - amt;
      await account.save({ transaction: t });

      await db.Transaction.create({
        type: 'purchase',
        amount: amt,
        description,
        fromAccountId: account.id,
        toAccountId: null
      }, { transaction: t });

      await t.commit();
      res.redirect('/');
    } catch (err) {
      await t.rollback();
      console.error(err);
      res.redirect('/?error=purchase_failed');
    }
  },

  createTransfer: async (req, res) => {
    const { fromAccountId, toAccountId, amount, description } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) return res.redirect('/?error=invalid_amount');
    if (!fromAccountId || !toAccountId) return res.redirect('/?error=invalid_accounts');
    if (fromAccountId === toAccountId) return res.redirect('/?error=same_account');

    const t = await sequelize.transaction();
    try {
      const fromAcc = await db.Account.findByPk(fromAccountId, { transaction: t, lock: t.LOCK.UPDATE });
      const toAcc = await db.Account.findByPk(toAccountId, { transaction: t, lock: t.LOCK.UPDATE });

      if (!fromAcc || !toAcc) {
        await t.rollback();
        return res.redirect('/?error=' + encodeURIComponent('Счёт не найден'));
      }
      if (parseFloat(fromAcc.balance) < amt) {
        await t.rollback();
        return res.redirect('/?error=' + encodeURIComponent('Недостаточно средств на счёте'));
      }

      fromAcc.balance = parseFloat(fromAcc.balance) - amt;
      toAcc.balance = parseFloat(toAcc.balance) + amt;

      await fromAcc.save({ transaction: t });
      await toAcc.save({ transaction: t });

      await db.Transaction.create({
        type: 'transfer',
        amount: amt,
        description,
        fromAccountId: fromAcc.id,
        toAccountId: toAcc.id
      }, { transaction: t });

      await t.commit();
      res.redirect('/');
    } catch (err) {
      await t.rollback();
      console.error(err);
      res.redirect('/?error=transfer_failed');
    }
  }
};
