const express = require('express');
const router = express.Router();
const accountController = require('../controllers/accountController');
const transactionController = require('../controllers/transactionController');
const db = require('../models');

router.get('/', accountController.dashboard);

router.post('/deposit', transactionController.createDeposit);
router.post('/purchase', transactionController.createPurchase);
router.post('/transfer', transactionController.createTransfer);

router.post('/accounts', async (req, res) => {
  try {
    const { userId, name, balance } = req.body;
    await db.Account.create({ userId, name, balance: parseFloat(balance || 0) });
    res.redirect('/');
  } catch (err) {
    console.error(err);
    res.redirect('/?error=account_create');
  }
});

module.exports = router;
