const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '..', 'database.sqlite'),
  logging: false
});

const db = {};
db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.User = require('./user')(sequelize, DataTypes);
db.Account = require('./account')(sequelize, DataTypes);
db.Transaction = require('./transaction')(sequelize, DataTypes);

db.User.hasMany(db.Account, { foreignKey: 'userId', onDelete: 'CASCADE' });
db.Account.belongsTo(db.User, { foreignKey: 'userId' });

// Define associations for transactions (explicit)
db.Account.hasMany(db.Transaction, { foreignKey: 'fromAccountId', as: 'OutTransactions' });
db.Account.hasMany(db.Transaction, { foreignKey: 'toAccountId', as: 'InTransactions' });

// explicit belongsTo associations for convenience
db.Transaction.belongsTo(db.Account, { foreignKey: 'fromAccountId', as: 'FromAccount' });
db.Transaction.belongsTo(db.Account, { foreignKey: 'toAccountId', as: 'ToAccount' });

module.exports = db;
