module.exports = (sequelize, DataTypes) => {
  const Transaction = sequelize.define('Transaction', {
    type: {
      type: DataTypes.ENUM('deposit','purchase','transfer'),
      allowNull: false
    },
    amount: { type: DataTypes.DECIMAL(12,2), allowNull: false },
    description: { type: DataTypes.STRING, allowNull: true },
    fromAccountId: { type: DataTypes.INTEGER, allowNull: true },
    toAccountId: { type: DataTypes.INTEGER, allowNull: true }
  }, { timestamps: true });

  return Transaction;
};
